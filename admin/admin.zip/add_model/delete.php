<?php
session_start();
if(isset($_GET['id'])){

    include('../db.php');

    $id = $_GET['id'];

    $sql = "DELETE FROM gallery WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = "Изображение успешно удалено!";
        header("Location: ./edit.php?id=".$_GET['model']);
        exit();
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}else{
    header("Location: ./");
    exit();
}

?>