<?php

session_start();

include("../db.php");

if(isset($_GET['id'])){
  $sql = "SELECT * FROM model WHERE id=".$_GET['id'];
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {

      if(isset($_POST['load_model'])){
        $type=$_POST['type'];
        $model_name=$_POST['name'];
        $description=$_POST['description'];
     
        $maxsize = 10485760; // 5MB
        if(isset($_FILES['file']['name']) && $_FILES['file']['name'] != ''){
            $name = $_FILES['file']['name'];
            $target_dir = "../../assets/photos/";
            $target_file = $target_dir . $_FILES["file"]["name"];
     
            // Select file type
            $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
     
            // Valid file extensions
            $extensions_arr = array("jpeg","jpg","png");
     
            // Check extension
            if(in_array($extension,$extensions_arr) ){
      
                // Check file size
                if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
                     $_SESSION['message'] = "Файл слишком большой. Размер файла должен быть меньше 10 МБ.";
                }else{
                     // Upload
                     if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                         // Insert record
                         $query = "UPDATE model SET type='".$type."',model_picture='".$name."',name='".$model_name."',description='".$description."' WHERE id=".$_GET['id'];
     
                         mysqli_query($conn,$query);
                         $_SESSION['success'] = "Загрузка успешно.";
                         header("Refresh:0");
                     }
                }
     
            }else{
                $_SESSION['message'] = "Недопустимое расширение файла.";
            }
        }else{
            $_SESSION['message'] = "Пожалуйста, выберите файл.";
        }
       //  header('location: index.php');
       //  exit;
     } 

     if(isset($_POST['load_banner'])){
      $maxsize = 10485760; // 5MB
      if(isset($_FILES['file']['name']) && $_FILES['file']['name'] != ''){
          $name = $_FILES['file']['name'];
          $target_dir = "../../assets/photos/";
          $target_file = $target_dir . $_FILES["file"]["name"];
   
          // Select file type
          $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   
          // Valid file extensions
          $extensions_arr = array("jpeg","jpg","png");
   
          // Check extension
          if(in_array($extension,$extensions_arr) ){
    
              // Check file size
              if(($_FILES['file']['size'] >= $maxsize) || ($_FILES["file"]["size"] == 0)) {
                   $_SESSION['message'] = "Файл слишком большой. Размер файла должен быть меньше 10 МБ.";
              }else{
                   // Upload
                   if(move_uploaded_file($_FILES['file']['tmp_name'],$target_file)){
                       // Insert record
                       $query = "UPDATE model SET banner='".$name."' WHERE id=".$_GET['id'];
   
                       mysqli_query($conn,$query);
                       $_SESSION['success'] = "Загрузка успешно.";
                       header("Refresh:0");
                   }
              }
   
          }else{
              $_SESSION['message'] = "Недопустимое расширение файла.";
          }
      }else{
          $_SESSION['message'] = "Пожалуйста, выберите файл.";
      }
     //  header('location: index.php');
     //  exit;
   } 


  //  modelinfo_load

  if(isset($_POST['modelinfo_load'])){
    $model_info_text = $_POST['model_info_text'];
    $maxsize = 10485760; // 5MB
    if((isset($_FILES['file1']['name']) && $_FILES['file1']['name'] != '') && (isset($_FILES['file2']['name']) && $_FILES['file2']['name'] != '') && (isset($_FILES['file3']['name']) && $_FILES['file3']['name'] != '')){
        $name1 = $_FILES['file1']['name'];
        $name2 = $_FILES['file2']['name'];
        $name3 = $_FILES['file3']['name'];
        $target_dir = "../../assets/photos/";
        $target_file1 = $target_dir . $_FILES["file1"]["name"];
        $target_file2 = $target_dir . $_FILES["file2"]["name"];
        $target_file3 = $target_dir . $_FILES["file3"]["name"];
 
        // Select file type
        $extension1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
        $extension2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
        $extension3 = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
 
        // Valid file extensions
        $extensions_arr = array("jpeg","jpg","png");
 
        // Check extension
        if((in_array($extension1,$extensions_arr)) && (in_array($extension2,$extensions_arr)) && (in_array($extension3,$extensions_arr)) ){
  
            // Check file size
            if(($_FILES['file1']['size'] >= $maxsize) || ($_FILES["file1"]["size"] == 0) && ($_FILES['file2']['size'] >= $maxsize) || ($_FILES["file2"]["size"] == 0) && ($_FILES['file3']['size'] >= $maxsize) || ($_FILES["file3"]["size"] == 0)) {
                 $_SESSION['message'] = "Файл слишком большой. Размер файла должен быть меньше 10 МБ.";
            }else{
                 // Upload
                 if(move_uploaded_file($_FILES['file1']['tmp_name'],$target_file1) && move_uploaded_file($_FILES['file2']['tmp_name'],$target_file2) && move_uploaded_file($_FILES['file3']['tmp_name'],$target_file3)){
                     // Insert record
                     $query = "UPDATE model SET model_info_1='".$name1."',model_info_2='".$name2."',model_info_3='".$name3."',model_info_text='".$model_info_text."' WHERE id=".$_GET['id'];
 
                     mysqli_query($conn,$query);
                     header("Refresh:0");
                     $_SESSION['success'] = "Загрузка успешно.";
                 }
            }
 
        }else{
            $_SESSION['message'] = "Недопустимое расширение файла.";
        }
    }else{
        $_SESSION['message'] = "Пожалуйста, выберите файл.";
    }
   //  header('location: index.php');
   //  exit;
  } 

    //  character_load

    if(isset($_POST['character_load'])){
      $character_wheel = $_POST['character_wheel'];
      $character_range = $_POST['character_range'];
      $character_front = $_POST['character_front'];
      $character_tire = $_POST['character_tire'];
      $character_lwh = $_POST['character_lwh'];
      $character_rear = $_POST['character_rear'];
      $maxsize = 10485760; // 5MB
      if((isset($_FILES['file1']['name']) && $_FILES['file1']['name'] != '') && (isset($_FILES['file2']['name']) && $_FILES['file2']['name'] != '') && (isset($_FILES['file3']['name']) && $_FILES['file3']['name'] != '')){
          $name1 = $_FILES['file1']['name'];
          $name2 = $_FILES['file2']['name'];
          $name3 = $_FILES['file3']['name'];
          $target_dir = "../../assets/photos/";
          $target_file1 = $target_dir . $_FILES["file1"]["name"];
          $target_file2 = $target_dir . $_FILES["file2"]["name"];
          $target_file3 = $target_dir . $_FILES["file3"]["name"];
   
          // Select file type
          $extension1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
          $extension2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
          $extension3 = strtolower(pathinfo($target_file3,PATHINFO_EXTENSION));
   
          // Valid file extensions
          $extensions_arr = array("jpeg","jpg","png");
   
          // Check extension
          if((in_array($extension1,$extensions_arr)) && (in_array($extension2,$extensions_arr)) && (in_array($extension3,$extensions_arr)) ){
    
              // Check file size
              if(($_FILES['file1']['size'] >= $maxsize) || ($_FILES["file1"]["size"] == 0) && ($_FILES['file2']['size'] >= $maxsize) || ($_FILES["file2"]["size"] == 0) && ($_FILES['file3']['size'] >= $maxsize) || ($_FILES["file3"]["size"] == 0)) {
                   $_SESSION['message'] = "Файл слишком большой. Размер файла должен быть меньше 10 МБ.";
              }else{
                   // Upload
                   if(move_uploaded_file($_FILES['file1']['tmp_name'],$target_file1) && move_uploaded_file($_FILES['file2']['tmp_name'],$target_file2) && move_uploaded_file($_FILES['file3']['tmp_name'],$target_file3)){
                       // Insert record
                       $query = "UPDATE model SET character_1='".$name1."',character_2='".$name2."',character_3='".$name3."',character_wheel='".$character_wheel."',character_range='".$character_range."',character_front='".$character_front."',character_tire='".$character_tire."',character_lwh='".$character_lwh."',character_rear='".$character_rear."' WHERE id=".$_GET['id'];

                       mysqli_query($conn,$query);
                       header("Refresh:0");
                       $_SESSION['success'] = "Загрузка успешно.";
                   }
              }
   
          }else{
              $_SESSION['message'] = "Недопустимое расширение файла.";
          }
      }else{
          $_SESSION['message'] = "Пожалуйста, выберите файл.";
      }
     //  header('location: index.php');
     //  exit;
    } 


        //  price_load

        if(isset($_POST['price_load'])){
          $price = $_POST['price'];
          $price_duration = $_POST['price_duration'];
          $price_month = $_POST['price_month'];
          
          // Insert record
          $query = "UPDATE model SET price='".$price."',price_duration='".$price_duration."',price_month='".$price_month."' WHERE id=".$_GET['id'];

          mysqli_query($conn,$query);
          header("Refresh:0");
          $_SESSION['success'] = "Загрузка успешно.";

         //  header('location: index.php');
         //  exit;
        } 



        if(isset($_POST['gallery_load'])){

          $maxsize = 10485760; // 5MB

          $storeFilesBasename='';
          // Count total uploaded files
          $totalfiles = count($_FILES['file']['name']);
         
          // Looping over all files
          for($i=0;$i<$totalfiles;$i++){
          $filename = $_FILES['file']['name'][$i];

          $target_dir = "../../assets/photos/";
          $target_file = $target_dir . $_FILES["file"]["name"][$i];
   
          // Select file type
          $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
   
          // Valid file extensions
          $extensions_arr = array("jpeg","jpg","png");
   
          // Check extension
          if((in_array($extension,$extensions_arr)) ){
    
              // Check file size
              if(($_FILES['file']['size'][$i] >= $maxsize) || ($_FILES["file"]["size"][$i] == 0)) {
                   $_SESSION['message'] = "Файл слишком большой. Размер файла должен быть меньше 10 МБ.";
              }else{
          
         // Upload files and store in database
         if(move_uploaded_file($_FILES["file"]["tmp_name"][$i],'../../assets/photos/'.$filename)){

              $sql = "INSERT INTO gallery (url, model) VALUES ('".$filename."', '".$_GET['id']."')";

              if ($conn->query($sql) === TRUE) {
                $_SESSION['success'] = "Загрузка успешно.";
              } else {
                $_SESSION['message'] = "Error: " . $sql . "<br>" . $conn->error;
              }

           }
          }
   
        }else{
            $_SESSION['message'] = "Недопустимое расширение файла.";
        }
          
          }


         } 


?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
    integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <title>Admin</title>
</head>

<body>
  <main class="d-flex flex-nowrap" style="height: 100vh;">
    <div class="d-flex flex-column flex-shrink-0 p-3 text-bg-dark" style="width: 340px;">
      <img src="../assets/logo.png" alt="logo" width="24" class="mb-4 mt-4 m-auto text-decoration-none">
      <hr>
      <ul class="nav nav-pills flex-column gap-3 mb-auto">
        <li class="nav-item">
          <a href="../lidlar/" class="nav-link text-white">
            <i class="fa-solid fa-user-tag"></i>
            Список тест-драйвов
          </a>
        </li>
        <li>
          <a href="../add_banner/" class="nav-link text-white">
            <i class="fa-solid fa-photo-film"></i>
            Информация о странице
          </a>
        </li>
        <li>
          <a href="../add_model/" class="nav-link text-white">
            <i class="fa-solid fa-car"></i>
            Добавить модель
          </a>
        </li>
        <li>
          <a href="../add_news/" class="nav-link text-white">
            <i class="fa-solid fa-newspaper"></i>
            Новости
          </a>
        </li>
        <li>
          <a href="../add_location/" class="nav-link text-white">
            <i class="fa-solid fa-map-location-dot"></i>
            Филиалы
          </a>
        </li>
      </ul>
      <hr>
      <div class="dropdown">
        <ul class="nav nav-pills flex-column mb-auto">
          <li>
            <a href="./" class="nav-link text-white">
              <i class="fa-solid fa-right-from-bracket fa-rotate-180"></i>
              Назад
            </a>
          </li>
        </ul>
      </div>
    </div>

    <div class="p-3 overflow-scroll" style="width: 100%;height: 100vh;">
      <div class="mb-5 d-flex justify-content-between">
        <h2><?php echo $row['name']?></h2>
        <button class="btn btn-danger" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Изменить
          модель</button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Изменить модель</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                  <form id="model" method="post" action="" enctype='multipart/form-data' class="m-auto">
                    <div class="mb-3">
                        <select class="form-select" name="type" required>
                          <option selected value="<?php echo $row['type'] ?>"><?php echo $row['type'] ?></option>
                          <option value="sedan">Sedan</option>
                          <option value="suv">Suv</option>
                          <option value="ev">Ev</option>
                        </select>
                      </div>
                        <div class="mb-3">
                          <label class="form-label">Загрузите изображение модели <span class="text-danger">*</span></label>
                          <input class="form-control" type="file" name="file" required>
                          <span class="text-secondary">Размер файла не должен превышать 10 МБ, (JPEG, PNG, MP4)</span>
                        </div>
                        <div class="mb-3">
                          <label class="form-label">Введите название модели <span class="text-danger">*</span></label>
                          <input type="text" class="form-control" placeholder="Введите" name="name" required value="<?php echo $row['name'] ?>">
                        </div>
                        <div class="mb-3">
                          <label class="form-label">Введите краткое описание модели <span class="text-danger">*</span></label>
                          <input type="text" class="form-control" placeholder="Введите" name="description" required value="<?php echo $row['description'] ?>">
                        </div>
                  </form>
              </div>
              <div class="modal-footer">
                <button type="submit" form="model" name="load_model" class="btn btn-danger">Добавить модель</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <?php 
                  if(isset($_SESSION['message'])){
                ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert" id="success-alert">
                   <?php echo $_SESSION['message'] ?>
                   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <?php
                    unset($_SESSION['message']);
                  }elseif(isset($_SESSION['success'])){
                    ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert" id="success-alert">
                       <?php echo $_SESSION['success'] ?>
                       <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php
                    unset($_SESSION['success']);
                  }
            ?>

      <div class="bg-body-tertiary p-3 rounded-2">
        <p>Баннер</p>
        <hr>
        <div class="mb-3 d-flex align-items-start gap-3">
          <?php
          
          if(isset($row['banner'])){
            ?>
            <img src="../../assets/photos/<?php echo $row['banner'] ?>" width="33%" height="250" style="object-fit: cover;" class="rounded">
            <?php

          }

          ?>
          <a type="button" data-bs-toggle="modal" data-bs-target="#banner"
            class="btn btn-danger text-uppercase rounded-circle d-flex justify-content-center align-items-center"
            style="width: 45px;height: 45px;"><i class="fa-solid fa-pen-to-square"></i></a>

          <!-- Modal -->
          <div class="modal fade" id="banner" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content">
                <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Изменить Баннер</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <form id="banner_load" method="post" action="" enctype='multipart/form-data' class="m-auto">
                    <div class="mb-3">
                      <label class="form-label">Загрузите Баннер модели <span class="text-danger">*</span></label>
                      <input class="form-control" type="file" name="file" required>
                      <span class="text-secondary">Размер файла не должен превышать 10 МБ, (JPEG, PNG)</span>
                    </div>
                  </form>
                </div>
                <div class="modal-footer">
                  <button type="submit" form="banner_load" name="load_banner" class="btn btn-danger">Загрузить</button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <p>О модели</p>
        <hr>

        <div class="row">

        <?php
          
          if(isset($row['model_info_1'])){
            ?>
            <div class="col-4 mb-4">
              <img src="../../assets/photos/<?php echo $row['model_info_1'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
            </div>
            <?php

          }

          if(isset($row['model_info_2'])){
            ?>
            <div class="col-4 mb-4">
              <img src="../../assets/photos/<?php echo $row['model_info_2'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
            </div>
            <?php

          }

          if(isset($row['model_info_3'])){
            ?>
            <div class="col-4 mb-4">
              <img src="../../assets/photos/<?php echo $row['model_info_3'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
            </div>
            <?php

          }

          ?>
        </div>

        <?php
          if(isset($row['model_info_text'])){
            ?>
            <p><?php echo $row['model_info_text'] ?></p>
            <?php

          }
        ?>

        <a type="button" data-bs-toggle="modal" data-bs-target="#modelmodal"
          class="btn btn-danger mb-3 text-uppercase rounded-circle d-flex justify-content-center align-items-center"
          style="width: 45px;height: 45px;"><i class="fa-solid fa-pen-to-square"></i></a>

        <!-- Modal -->
        <div class="modal fade" id="modelmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Изменить Баннер</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form id="modelinfo_load" method="post" action="" enctype='multipart/form-data' class="m-auto">
                  <div class="mb-3">
                    <label class="form-label">Загрузить изображение 1<span class="text-danger">*</span></label>
                    <input class="form-control" type="file" name="file1" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Загрузить изображение 2<span class="text-danger">*</span></label>
                    <input class="form-control" type="file" name="file2" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Загрузить изображение 3<span class="text-danger">*</span></label>
                    <input class="form-control" type="file" name="file3" required>
                    <span class="text-secondary">Размер файла не должен превышать 10 МБ, (JPEG, PNG)</span>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Введите информацию о модели.</label>
                    <textarea class="form-control" rows="3" name="model_info_text" required></textarea>
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="submit" form="modelinfo_load" name="modelinfo_load" class="btn btn-danger">Загрузить</button>
              </div>
            </div>
          </div>
        </div>

        <p>Характеристики</p>
        <hr>

        <div class="row">
        <?php
          
          if(isset($row['character_1'])){
            ?>
            <div class="col-4 mb-4">
              <img src="../../assets/photos/<?php echo $row['character_1'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
              <p class="m-0 mt-3">Wheel base [mm]</p>
              <h3><?php echo $row['character_wheel'] ?></h3>
              <p class="m-0 mt-3">10 minutes super charge driving range</p>
              <h3><?php echo $row['character_range'] ?></h3>
            </div>
            <?php

          }

          if(isset($row['character_2'])){
            ?>
            <div class="col-4 mb-4">
              <img src="../../assets/photos/<?php echo $row['character_2'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
              <p class="m-0 mt-3">Front overhang (mm)</p>
              <h3><?php echo $row['character_front'] ?></h3>
              <p class="m-0 mt-3">Tire size</p>
              <h3><?php echo $row['character_tire'] ?></h3>
            </div>
            <?php

          }

          if(isset($row['character_3'])){
            ?>
            <div class="col-4 mb-4">
              <img src="../../assets/photos/<?php echo $row['character_3'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
              <p class="m-0 mt-3">L×W×H [mm]</p>
              <h3><?php echo $row['character_lwh'] ?></h3>
              <p class="m-0 mt-3">Rear overhang (mm)</p>
              <h3><?php echo $row['character_rear'] ?></h3>
            </div>
            <?php

          }
        ?>
        </div>

        <a type="button" data-bs-toggle="modal" data-bs-target="#character"
          class="btn btn-danger mb-3 text-uppercase rounded-circle d-flex justify-content-center align-items-center"
          style="width: 45px;height: 45px;"><i class="fa-solid fa-pen-to-square"></i></a>

        <!-- Modal -->
        <div class="modal fade" id="character" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Изменить Характеристики</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form id="character_load" method="post" action="" enctype='multipart/form-data' class="m-auto">
                  <div class="mb-3">
                    <label class="form-label">Загрузить изображение 1<span class="text-danger">*</span></label>
                    <input class="form-control" type="file" name="file1" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Загрузить изображение 2<span class="text-danger">*</span></label>
                    <input class="form-control" type="file" name="file2" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Загрузить изображение 3<span class="text-danger">*</span></label>
                    <input class="form-control" type="file" name="file3" required>
                    <span class="text-secondary">Размер файла не должен превышать 10 МБ, (JPEG, PNG)</span>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Wheel base [mm]</label>
                    <input type="text" class="form-control" name="character_wheel" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">10 minutes super charge driving range</label>
                    <input type="text" class="form-control" name="character_range" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Front overhang (mm)</label>
                    <input type="text" class="form-control" name="character_front" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Tire size</label>
                    <input type="text" class="form-control" name="character_tire" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">L×W×H [mm]</label>
                    <input type="text" class="form-control" name="character_lwh" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Rear overhang (mm)</label>
                    <input type="text" class="form-control" name="character_rear" required>
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="submit" form="character_load" name="character_load" class="btn btn-danger">Загрузить</button>
              </div>
            </div>
          </div>
        </div>

        <p>Цены</p>
        <hr>

        <div class="row">

        <?php
        if(isset($row['price'])){
            ?>
          <div class="col-4 mb-4">
            <p class="m-0 mt-3">Общая стоимость</p>
            <h3>$<?php echo $row['price']?></h3>
          </div>
            <?php

          }

        if(isset($row['price_duration'])){
            ?>
          <div class="col-4 mb-4">
            <p class="m-0 mt-3">Месяц рассрочки</p>
            <h3><?php echo $row['price_duration']?></h3>
          </div>
            <?php

          }

          if(isset($row['price_month'])){
            ?>
          <div class="col-4 mb-4">
            <p class="m-0 mt-3">Ежемесячно оплата</p>
            <h3>$<?php echo $row['price_month']?></h3>
          </div>
            <?php

          }
        ?>
        </div>

        <a href="./edit.php?" type="button" data-bs-toggle="modal" data-bs-target="#price"
          class="btn btn-danger mb-3 text-uppercase rounded-circle d-flex justify-content-center align-items-center"
          style="width: 45px;height: 45px;"><i class="fa-solid fa-pen-to-square"></i></a>

        <!-- Modal -->
        <div class="modal fade" id="price" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Изменить цены</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form id="price_load" action="" method="post" class="m-auto">

                  <div class="mb-3">
                    <label class="form-label">Общая стоимость</label>
                    <input type="number" class="form-control" name="price" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Месяц рассрочки</label>
                    <input type="number" class="form-control" name="price_duration" required>
                  </div>

                  <div class="mb-3">
                    <label class="form-label">Ежемесячно оплата</label>
                    <input type="number" class="form-control" name="price_month" required>
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="submit" form="price_load" name="price_load" class="btn btn-danger">Изменить цены</button>
              </div>
            </div>
          </div>
        </div>

        <p>Галерея</p>
        <hr>

        <div class="row">

        <?php
        
        $sql = "SELECT * FROM gallery WHERE model=".$_GET['id'];
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
            ?>
          <div class="col-4 mb-4" style="position: relative;">
              <a href="./delete.php?id=<?php echo $row['id']?>&model=<?php echo $_GET['id'] ?>" style="position: absolute;top: 5px;right: 17px;" class="rounded bg-dark text-white p-1 px-2">
                  <i class="fa-solid fa-xmark"></i>
              </a>
              <img src="../../assets/photos/<?php echo $row['url'] ?>" width="100%" height="250" style="object-fit: cover;" class="rounded">
          </div>
            <?php
          }
        } else {
          echo "<p>В галерее нет изображений</p>";
        }

        ?>
      </div>

      <a href="./edit.php?" type="button" data-bs-toggle="modal" data-bs-target="#gallery"
      class="btn btn-danger mb-3 text-uppercase rounded-circle d-flex justify-content-center align-items-center"
      style="width: 45px;height: 45px;"><i class="fa-solid fa-plus"></i></a>

    <!-- Modal -->
    <div class="modal fade" id="gallery" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="exampleModalLabel">Добавить изображение</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="gallery_load" action="" method="post" enctype="multipart/form-data" class="m-auto">
              <div class="mb-3">
                <label class="form-label">Загрузить изображение<span class="text-danger">*</span></label>
                <input class="form-control" type="file" name="file[]" multiple>
                <span class="text-secondary">Размер файла не должен превышать 10 МБ, (JPEG, PNG, MP4)</span>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="submit" form="gallery_load" name="gallery_load" class="btn btn-danger">Добавить</button>
          </div>
        </div>
      </div>
    </div>





      </div>
    </div>
  </main>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
  </script>
</body>

</html>

<?php
    }
  } else {
    header('Location: ./');
    exit;
  }
  $conn->close();
}else{
  header('Location: ./');
  exit;
}
?>