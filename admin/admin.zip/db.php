<?php
$servername = "localhost";
$username = "hongqi";
$password = "hongqi123@";
$dbname = "hongqi";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
?>