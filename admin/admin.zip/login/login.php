<?php 
session_start(); 
include "../db.php";
if (isset($_POST['username']) && isset($_POST['password'])) {

    function validate($data){
       $data = trim($data);
       $data = stripslashes($data);
       $data = htmlspecialchars($data);
       return $data;
    }

    $uname = validate($_POST['username']);
    $pass = validate($_POST['password']);

    if (empty($uname)) {
        header("Location: ./?error=Имя пользователя требуется");
        exit();
    }else if(empty($pass)){
        header("Location: ./?error=Необходим пароль");
        exit();
    }else{
        $sql = "SELECT * FROM admin WHERE username='$uname' AND password='$pass'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            if ($row['username'] === $uname && $row['password'] === $pass) {
                setcookie("login", $uname, time() + 2 * 24 * 60 * 60); 
                header("Location: ../lidlar/");
                exit();
            }else{
                header("Location: ./?error=Неверное имя пользователя или пароль");
                exit();
            }
        }else{
            header("Location: ./?error=Неверное имя пользователя или пароль");
            exit();
        }
    }
}else{
    header("Location: ./?error=Логин и пароль не вводятся!");
    exit();
}